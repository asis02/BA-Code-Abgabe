import serial
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import re

# ----------------------
PORT = 'COM7'  # <-- Deinen Port hier anpassen
BAUDRATE = 115200
FIELD_SIZE_CM = 800
# ----------------------

# Serielle Verbindung öffnen
ser = serial.Serial(PORT, BAUDRATE, timeout=1)

# Ankerpositionen
anchors = np.array([
    [0.0, 0.0],    # Anker 0
    [60.0, 0.0],   # Anker 1
    [30.0, -51.5]   # Anker 2
])

# Plot Setup
fig, ax = plt.subplots()
ax.set_xlim(-800, FIELD_SIZE_CM)
ax.set_ylim(-800, FIELD_SIZE_CM)
ax.set_xlabel('X Position (cm)')
ax.set_ylabel('Y Position (cm)')
ax.set_title('Live UWB Position Tracking')
ax.grid(True)
ax.axvline(x=30, color='red', linestyle='-', linewidth=1.5, label='Referenzlinie x=0')
ax.set_aspect('equal')  # <--- Diese Zeile sorgt für echte Kreise


# Plot-Objekte vorbereiten
anchor_scatter = ax.scatter(anchors[:, 0], anchors[:, 1], c='green', marker='s', label='Anchors')
tag_point, = ax.plot([], [], 'ro', label='Tag')

# Kreise um Anker (initial unsichtbar)
anchor_circles = [
    plt.Circle((0, 0), 0, color='blue', fill=False, linestyle='--') for _ in range(3)
]
for circle in anchor_circles:
    ax.add_patch(circle)

ax.legend()

# Trilaterationsfunktion
def trilateration(d0, d1, d2, anchors):
    x0, y0 = anchors[0]
    x1, y1 = anchors[1]
    x2, y2 = anchors[2]

    A = 2 * (x1 - x0)
    B = 2 * (y1 - y0)
    C = d0**2 - d1**2 - x0**2 + x1**2 - y0**2 + y1**2
    D = 2 * (x2 - x0)
    E = 2 * (y2 - y0)
    F = d0**2 - d2**2 - x0**2 + x2**2 - y0**2 + y2**2

    denominator = (A * E - B * D)
    if abs(denominator) < 1e-6:
        return None, None

    x = (C * E - F * B) / denominator
    y = (A * F - C * D) / denominator

    return x, y

# Update-Funktion
def update(frame):
    try:
        raw_line = ser.readline()
        try:
            line = raw_line.decode('utf-8').strip()
        except UnicodeDecodeError:
            return

        match = re.search(r'range:\((\d+),(\d+),(\d+)', line)
        if match:
            d0 = float(match.group(1))
            d1 = float(match.group(2))
            d2 = float(match.group(3))

            # Trilateration
            x, y = trilateration(d0, d1, d2, anchors)

            if x is not None and y is not None:
                # Update Tag-Position
                tag_point.set_data([x], [y])

                # Update Kreise um die Anker
                distances = [d0, d1, d2]
                for i in range(3):
                    anchor_circles[i].center = (anchors[i][0], anchors[i][1])
                    anchor_circles[i].radius = distances[i]

    except Exception as e:
        print("Fehler:", e)

# Animation starten
ani = animation.FuncAnimation(fig, update, interval=100)

plt.show()
