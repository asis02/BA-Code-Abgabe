import serial
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import re

# ----------------------
PORT = 'COM12'  # <-- Deinen Port hier anpassen
BAUDRATE = 115200
FIELD_SIZE_CM = 300
# ----------------------

# Serielle Verbindung öffnen
ser = serial.Serial(PORT, BAUDRATE, timeout=1)

# Ankerpositionen
anchors = np.array([
    [0.0, 0.0],    # Anker 0
    [60.0, 0.0],   # Anker 1
    [30.0, 20.0]   # Anker 2
])

# Plot Setup
fig, ax = plt.subplots()
ax.set_xlim(-300, FIELD_SIZE_CM)
ax.set_ylim(-300, FIELD_SIZE_CM)
ax.set_xlabel('X Position (cm)')
ax.set_ylabel('Y Position (cm)')
ax.set_title('Live UWB Position Tracking')
ax.grid(True)

ax.scatter(anchors[:, 0], anchors[:, 1], c='green', marker='s', label='Anchors')

tag_point, = ax.plot([], [], 'ro', label='Tag')  # Nur der Punkt!
ax.legend()

def trilateration(d0, d1, d2, anchors):
    x0, y0 = anchors[0]
    x1, y1 = anchors[1]
    x2, y2 = anchors[2]

    # Richtige Gleichungen
    A = 2 * (x1 - x0)
    B = 2 * (y1 - y0)
    C = d0**2 - d1**2 - x0**2 + x1**2 - y0**2 + y1**2
    D = 2 * (x2 - x0)
    E = 2 * (y2 - y0)
    F = d0**2 - d2**2 - x0**2 + x2**2 - y0**2 + y2**2

    denominator = (A * E - B * D)
    if abs(denominator) < 1e-6:
        return None, None  # Degenerierter Fall

    x = (C * E - F * B) / denominator
    y = (A * F - C * D) / denominator

    return x, y

def update(frame):
    try:
        raw_line = ser.readline()
        try:
            line = raw_line.decode('utf-8').strip()
        except UnicodeDecodeError:
            return

        match = re.search(r'range:\((\d+),(\d+),(\d+)', line)
        if match:
            d0 = float(match.group(1))
            d1 = float(match.group(2))
            d2 = float(match.group(3))

            x, y = trilateration(d0, d1, d2, anchors)

            if x is not None and y is not None:
                tag_point.set_data([x], [y])  # Nur den Punkt aktualisieren!

    except Exception as e:
        print("Fehler:", e)

ani = animation.FuncAnimation(fig, update, interval=50)

plt.show()
